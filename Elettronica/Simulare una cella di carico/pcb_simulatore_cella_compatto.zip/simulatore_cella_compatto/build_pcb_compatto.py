# build_pcb_compatto.py — simulatore bipolare compatto, footprint combinati 0805 / assiale passo 10,16 mm
import pcbnew
from pcbnew import VECTOR2I, FromMM

OUT = '/home/claude/pcb/compact/simulatore_cella_compatto/simulatore_cella_compatto.kicad_pcb'
X0, Y0 = 100.0, 99.0           # origine della scheda [mm]
W, H = 31.0, 25.0              # dimensioni della scheda [mm]
TRACK = 0.3                    # larghezza piste [mm]

board = pcbnew.BOARD()
board.SetCopperLayerCount(2)
ds = board.GetDesignSettings()
ds.SetCopperLayerCount(2)
ds.m_TrackMinWidth = FromMM(0.2)
ds.m_MinClearance = FromMM(0.2)

def P(x, y):
    return VECTOR2I(FromMM(x), FromMM(y))

# --- Reti ---
nets = {}
for name in ('E+', 'E-', 'A+', 'A-', 'X', 'Y'):
    n = pcbnew.NETINFO_ITEM(board, name)
    board.Add(n)
    nets[name] = n


def fix_local(fp):
    # il footprint è costruito nell'origine: le coordinate assolute coincidono con quelle locali
    for pad in fp.Pads():
        pad.SetPos0(pad.GetPosition())
    for item in fp.GraphicalItems():
        item.SetLocalCoord()
    fp.Reference().SetLocalCoord()
    fp.Value().SetLocalCoord()

# --- Footprint generati qui (equivalenti a quelli standard KiCad) ---
def text(fp, kind, txt, x, y, layer, size=0.8):
    t = fp.Reference() if kind == 'ref' else fp.Value()
    t.SetText(txt)
    t.SetLayer(layer)
    t.SetTextSize(VECTOR2I(FromMM(size), FromMM(size)))
    t.SetTextThickness(FromMM(0.12))
    t.SetPosition(P(x, y))

def fp_r0805(ref, val, x, y, n1, n2, vertical=False, lbl=None):
    fp = pcbnew.FOOTPRINT(board)
    fp.SetFPID(pcbnew.LIB_ID('Simulatore', 'R_0805_2012Metric'))
    ox, oy = x, y
    x, y = 0.0, 0.0
    for num, dx, net in (('1', -0.9125, n1), ('2', 0.9125, n2)):
        pad = pcbnew.PAD(fp)
        pad.SetNumber(num)
        pad.SetShape(pcbnew.PAD_SHAPE_ROUNDRECT)
        pad.SetRoundRectRadiusRatio(0.243902)
        pad.SetAttribute(pcbnew.PAD_ATTRIB_SMD)
        pad.SetLayerSet(pad.SMDMask())
        pad.SetSize(VECTOR2I(FromMM(1.025), FromMM(1.4)))
        pad.SetPosition(P(x + dx, y))
        pad.SetNet(nets[net])
        fp.Add(pad)
    # sagoma sul layer Fab e serigrafia minima
    for (xa, ya, xb, yb) in ((-1, -0.625, 1, -0.625), (1, -0.625, 1, 0.625), (1, 0.625, -1, 0.625), (-1, 0.625, -1, -0.625)):
        seg = pcbnew.FP_SHAPE(fp, pcbnew.SHAPE_T_SEGMENT)
        seg.SetStart(P(x + xa, y + ya)); seg.SetEnd(P(x + xb, y + yb))
        seg.SetLayer(pcbnew.F_Fab); seg.SetWidth(FromMM(0.1))
        fp.Add(seg)
    fp.SetAttributes(pcbnew.FP_SMD)
    text(fp, 'val', val, 0, 0, pcbnew.F_Fab, 0.5)
    text(fp, 'ref', ref, 0, -1.6, pcbnew.F_SilkS)
    board.Add(fp)
    fix_local(fp)
    fp.SetPosition(P(ox, oy))
    if vertical:
        fp.SetOrientationDegrees(90)   # rotazione attorno al centro: pad 1 in basso, pad 2 in alto
    lx, ly = lbl if lbl else (ox, oy - 1.6)
    fp.Reference().SetPosition(P(lx, ly))
    if vertical:
        fp.Reference().SetTextAngleDegrees(-90)   # angolo relativo al footprint: testo orizzontale
    return fp

def fp_header(ref, val, x, y, n, netlist, labels=None, lib='PinHeader'):
    fp = pcbnew.FOOTPRINT(board)
    fp.SetFPID(pcbnew.LIB_ID('Simulatore', f'{lib}_1x{n:02d}_P2.54mm_Vertical'))
    ox, oy = x, y
    x, y = 0.0, 0.0
    for i in range(n):
        pad = pcbnew.PAD(fp)
        pad.SetNumber(str(i + 1))
        pad.SetShape(pcbnew.PAD_SHAPE_RECT if i == 0 else pcbnew.PAD_SHAPE_OVAL)
        pad.SetAttribute(pcbnew.PAD_ATTRIB_PTH)
        pad.SetLayerSet(pad.PTHMask())
        pad.SetSize(VECTOR2I(FromMM(1.7), FromMM(1.7)))
        pad.SetDrillSize(VECTOR2I(FromMM(1.0), FromMM(1.0)))
        pad.SetPosition(P(x, y + i * 2.54))
        pad.SetNet(nets[netlist[i]])
        fp.Add(pad)
    # rettangolo di serigrafia attorno ai pin
    r = (x - 1.33, y - 1.33, x + 1.33, y + (n - 1) * 2.54 + 1.33)
    for (xa, ya, xb, yb) in ((r[0], r[1], r[2], r[1]), (r[2], r[1], r[2], r[3]), (r[2], r[3], r[0], r[3]), (r[0], r[3], r[0], r[1])):
        seg = pcbnew.FP_SHAPE(fp, pcbnew.SHAPE_T_SEGMENT)
        seg.SetStart(P(xa, ya)); seg.SetEnd(P(xb, yb))
        seg.SetLayer(pcbnew.F_SilkS); seg.SetWidth(FromMM(0.12))
        fp.Add(seg)
    fp.SetAttributes(pcbnew.FP_THROUGH_HOLE)
    text(fp, 'ref', ref, 0, -2.4, pcbnew.F_SilkS)
    text(fp, 'val', val, 0, n * 2.54, pcbnew.F_Fab, 0.6)
    board.Add(fp)
    fix_local(fp)
    fp.SetPosition(P(ox, oy))
    return fp

def fp_hole(ref, x, y, d=3.2):
    fp = pcbnew.FOOTPRINT(board)
    fp.SetFPID(pcbnew.LIB_ID('Simulatore', 'MountingHole_2.7mm_M2.5' if d < 3 else 'MountingHole_3.2mm_M3'))
    ox, oy = x, y
    x, y = 0.0, 0.0
    pad = pcbnew.PAD(fp)
    pad.SetNumber('')
    pad.SetShape(pcbnew.PAD_SHAPE_CIRCLE)
    pad.SetAttribute(pcbnew.PAD_ATTRIB_NPTH)
    pad.SetLayerSet(pad.UnplatedHoleMask())
    pad.SetSize(VECTOR2I(FromMM(d), FromMM(d)))
    pad.SetDrillSize(VECTOR2I(FromMM(d), FromMM(d)))
    pad.SetPosition(P(x, y))
    fp.Add(pad)
    fp.Reference().SetVisible(False)
    fp.Value().SetVisible(False)
    fp.SetReference(ref)
    fp.SetAttributes(pcbnew.FP_EXCLUDE_FROM_BOM | pcbnew.FP_EXCLUDE_FROM_POS_FILES)
    board.Add(fp)
    fix_local(fp)
    fp.SetPosition(P(ox, oy))


PITCH = 10.16      # passo dei fori per resistenze assiali DIN0207 (1/4 W)

def fp_combo(ref, val, x, y, n1, n2, vertical=False, lbl=None):
    """Footprint combinato: pad 0805 al centro e fori per resistenza assiale, stessi numeri di pad."""
    fp = pcbnew.FOOTPRINT(board)
    fp.SetFPID(pcbnew.LIB_ID('Simulatore', 'R_Combo_0805_Axial_P10.16mm'))
    for num, sgn, net in (('1', -1, n1), ('2', 1, n2)):
        smd = pcbnew.PAD(fp)                                   # piazzola 0805 (come R_0805_2012Metric)
        smd.SetNumber(num)
        smd.SetShape(pcbnew.PAD_SHAPE_ROUNDRECT); smd.SetRoundRectRadiusRatio(0.243902)
        smd.SetAttribute(pcbnew.PAD_ATTRIB_SMD); smd.SetLayerSet(smd.SMDMask())
        smd.SetSize(VECTOR2I(FromMM(1.025), FromMM(1.4)))
        smd.SetPosition(P(sgn * 0.9125, 0)); smd.SetNet(nets[net])
        fp.Add(smd)
        tht = pcbnew.PAD(fp)                                   # foro per resistenza assiale
        tht.SetNumber(num)
        tht.SetShape(pcbnew.PAD_SHAPE_RECT if num == '1' else pcbnew.PAD_SHAPE_CIRCLE)
        tht.SetAttribute(pcbnew.PAD_ATTRIB_PTH); tht.SetLayerSet(tht.PTHMask())
        tht.SetSize(VECTOR2I(FromMM(1.6), FromMM(1.6)))
        tht.SetDrillSize(VECTOR2I(FromMM(0.8), FromMM(0.8)))
        tht.SetPosition(P(sgn * PITCH / 2, 0)); tht.SetNet(nets[net])
        fp.Add(tht)
    # sagoma del corpo assiale DIN0207 (6,3 x 2,5 mm) in serigrafia: contiene le piazzole 0805
    for (xa, ya, xb, yb) in ((-3.15, -1.25, 3.15, -1.25), (3.15, -1.25, 3.15, 1.25), (3.15, 1.25, -3.15, 1.25), (-3.15, 1.25, -3.15, -1.25)):
        seg = pcbnew.FP_SHAPE(fp, pcbnew.SHAPE_T_SEGMENT)
        seg.SetStart(P(xa, ya)); seg.SetEnd(P(xb, yb))
        seg.SetLayer(pcbnew.F_SilkS); seg.SetWidth(FromMM(0.12))
        fp.Add(seg)
    fp.SetAttributes(0)                                         # né solo SMD né solo THT: montaggio a scelta
    text(fp, 'val', val, 0, 0, pcbnew.F_Fab, 0.5)
    text(fp, 'ref', ref, 0, -2.2, pcbnew.F_SilkS)
    board.Add(fp)
    fix_local(fp)
    fp.SetPosition(P(x, y))
    if vertical:
        fp.SetOrientationDegrees(90)                            # pad 1 in basso, pad 2 in alto
        fp.Reference().SetTextAngleDegrees(-90)
    lx, ly = lbl if lbl else (x, y - 2.2)
    fp.Reference().SetPosition(P(lx, ly))
    # collegamento fisico tra piazzola SMD e foro con lo stesso numero
    pads = {}
    for pad in fp.Pads():
        pads.setdefault(pad.GetNumber(), []).append(pad)
    for num, pp in pads.items():
        a, b = pp[0].GetPosition(), pp[1].GetPosition()
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(a); t.SetEnd(b); t.SetWidth(FromMM(0.4)); t.SetLayer(pcbnew.F_Cu)
        t.SetNet(pp[0].GetNet())
        board.Add(t)
    return fp


# --- Coordinate di progetto (mm): sei resistenze in colonna, passo 3,2 mm ---
ROW = 3.2
xJ, xL = 104.0, 110.0
xR = xL + PITCH                                  # 120,16
xV = 126.0
rows = [104.0 + k * ROW for k in range(6)]       # 104,0 107,2 110,4 113,6 116,8 120,0
yc = (rows[2] + rows[3]) / 2                     # 112,0: asse di A+
yJ = [yc - 2.54, yc, yc + 2.54, yc + 5.08]       # J1: E+, A+, A-, E-
yV = [yc - 2.54, yc, yc + 2.54]                  # RV1: X, cursore, Y
xc = (xL + xR) / 2

# ordine: R1, R2 (E+ / X), R5 (M / X), R6 (M / Y), R3, R4 (E- / Y); pad 1 a sinistra
order = [('R1', 'E+', 'X'), ('R2', 'E+', 'X'), ('R5', 'A-', 'X'), ('R6', 'A-', 'Y'), ('R3', 'E-', 'Y'), ('R4', 'E-', 'Y')]
for (ref, n1, n2), y in zip(order, rows):
    fp_combo(ref, '47k', xc, y, n1, n2, lbl=(122.6, y))

fp_header('J1', 'Conn_01x04', xJ, yJ[0], 4, ['E+', 'A+', 'A-', 'E-'])
rv = fp_header('RV1', '200R 3296W / 3590S', xV, yV[0], 3, ['X', 'A+', 'Y'], lib='Trimmer')
rv.Reference().SetPosition(P(xV, yV[2] + 2.5))
for (hx, hy) in ((103.0, 102.0), (128.0, 102.0), (103.0, 121.0), (128.0, 121.0)):
    fp_hole('H', hx, hy, 2.7)

def track(points, net, layer=pcbnew.F_Cu):
    for (a, b) in zip(points[:-1], points[1:]):
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(P(*a)); t.SetEnd(P(*b))
        t.SetWidth(FromMM(TRACK)); t.SetLayer(layer); t.SetNet(nets[net])
        board.Add(t)

# colonna sinistra: E+ (file 1-2), M = A- (file 3-4), E- (file 5-6)
track([(xL, rows[0]), (xL, rows[1])], 'E+')
track([(xL, rows[1]), (xL - (yJ[0] - rows[1]), yJ[0]), (xJ, yJ[0])], 'E+')
track([(xL, rows[2]), (xL, rows[3])], 'A-')
track([(xL, rows[3]), (xL - (yJ[2] - rows[3]), yJ[2]), (xJ, yJ[2])], 'A-')
track([(xL, rows[4]), (xL, rows[5])], 'E-')
track([(xL, rows[4]), (xL - (yJ[3] - rows[4]), yJ[3]), (xJ, yJ[3])], 'E-')
# colonna destra: X (file 1-3), Y (file 4-6)
track([(xR, rows[0]), (xR, rows[2])], 'X')
track([(xR, rows[2]), (xR + (rows[2] - yV[0]), yV[0]), (xV, yV[0])], 'X')
track([(xR, rows[3]), (xR, rows[5])], 'Y')
track([(xR, rows[3]), (xR + (yV[2] - rows[3]), yV[2]), (xV, yV[2])], 'Y')
# A+ sul lato rame: diritta da RV1-2 a J1-2, tra la terza e la quarta fila
track([(xV, yc), (xJ, yc)], 'A+', pcbnew.B_Cu)

def edge(xa, ya, xb, yb):
    s = pcbnew.PCB_SHAPE(board, pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(P(xa, ya)); s.SetEnd(P(xb, yb))
    s.SetLayer(pcbnew.Edge_Cuts); s.SetWidth(FromMM(0.1))
    board.Add(s)
edge(X0, Y0, X0 + W, Y0); edge(X0 + W, Y0, X0 + W, Y0 + H)
edge(X0 + W, Y0 + H, X0, Y0 + H); edge(X0, Y0 + H, X0, Y0)

def silk(txt, x, y, size=0.8, layer=pcbnew.F_SilkS):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(txt); t.SetLayer(layer)
    t.SetTextSize(VECTOR2I(FromMM(size), FromMM(size)))
    t.SetTextThickness(FromMM(0.15 if size >= 1 else 0.12))
    t.SetPosition(P(x, y))
    if layer == pcbnew.B_SilkS:
        t.SetMirrored(True)
    board.Add(t)

silk('CELLA ±2,11 mV/V', 115.5, 100.7, 0.8)
for i, lab in enumerate(('E+', 'A+', 'A-', 'E-')):
    silk(lab, 101.6, yJ[i], 0.8)
for lab, y in zip(('X', 'W', 'Y'), yV):
    silk(lab, 128.4, y, 0.8)
silk('47k 0805 o assiale P10,16', 115.5, 122.8, 0.8)
silk('rev C 10/2026', 115.5, 122.8, 0.8, pcbnew.B_SilkS)
silk('A+', 115.0, yc - 1.0, 0.8, pcbnew.B_SilkS)

board.SetFileName(OUT)
pcbnew.SaveBoard(OUT, board)
print('salvato', OUT)
