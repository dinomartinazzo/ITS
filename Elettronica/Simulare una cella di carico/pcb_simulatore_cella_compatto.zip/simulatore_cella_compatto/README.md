# Simulatore di cella di carico — PCB rev C (compatto, footprint combinati)

Simulatore bipolare (configurazione B della dispensa) in formato compatto.
Le sei resistenze sono in una sola colonna, nell'ordine R1, R2, R5, R6, R3, R4: le reti
scendono in sequenza E+ → X → M → Y → E− e A+ diventa una pista diritta sul lato rame.

Ogni resistenza ha un **footprint combinato**: piazzole 0805 al centro e fori per resistenza
assiale DIN0207 (1/4 W) a passo 10,16 mm. In ogni posizione si monta **una sola** delle due.

Fondo scala **±2,114 mV/V** con resistenze da 47 kΩ; zero circa a metà corsa del potenziometro.

## Caratteristiche della scheda

| Parametro | Valore |
|---|---|
| Dimensioni | 31 × 25 mm (rev B: 58 × 48 mm, −72% di superficie) |
| Fori di fissaggio | 4 × M2,5 (Ø 2,7 mm) |
| Strati | 2 (rame 1 oz), spessore 1,6 mm |
| Passo tra le file di resistenze | 3,2 mm |
| Piste | 0,3 mm (0,4 mm tra piazzola SMD e foro); isolamento minimo 0,2 mm |
| DRC (KiCad 7.0.11) | 0 violazioni, 0 pad non collegati |

## Lato componenti e lato rame

| Lato | Contenuto |
|---|---|
| Componenti (F) | Piazzole 0805, tutte le piste tranne A+, serigrafia |
| Rame (B) | Solo la pista A+, da RV1-2 a J1-2, tra la terza e la quarta fila; piazzole dei fori |

Viste: `anteprima_lato_componenti.png`, `anteprima_lato_rame.png` (vista da sotto, speculare).

## Stampe in scala 1:1 (cartella `stampa_1a1/`)

| File | Uso |
|---|---|
| `lato_componenti_rame_SPECCHIATO.pdf` | Rame del lato componenti, specchiato: per trasferimento a toner o fotoincisione con il lato stampato a contatto del rame |
| `lato_rame_rame.pdf` | Rame del lato saldature, già nel verso corretto per il trasferimento |
| `serigrafia_lato_componenti.pdf` | Guida al montaggio con riferimenti e sagome |

Stampare al 100%, senza adattamento alla pagina; controllare con un righello: scheda 31 × 25 mm.
La scheda è a due facce: in incisione casalinga servono l'allineamento dei due lati e,
in alternativa ai fori metallizzati, un filo saldato da entrambe le parti in J1-2 e RV1-2.

## Connessioni

| Pin | J1 (verso il convertitore) | RV1 (potenziometro) |
|---|---|---|
| 1 | E+ | X (pad quadrato) |
| 2 | A+ | cursore |
| 3 | A− | Y |
| 4 | E− | — |

## File

| File | Contenuto |
|---|---|
| `simulatore_cella_compatto.kicad_pro`, `.kicad_pcb` | Progetto KiCad 7 |
| `fp-lib-table`, `Simulatore.pretty/` | Libreria dei footprint |
| `gerber/` | Gerber RS-274X, forature Excellon, file di job |
| `stampa_1a1/` | Stampe in scala 1:1 per realizzazione in laboratorio |
| `simulatore_cella_compatto-bom.csv` | Distinta componenti |
| `simulatore_cella_compatto-pos-0805.csv` | Piazzamento delle 0805 |
| `build_pcb_compatto.py` | Script che genera la scheda con l'API pcbnew |

## Montaggio e collaudo

1. Montare in ogni posizione la 0805 oppure la resistenza assiale, mai entrambe.
2. Saldare J1 e RV1.
3. Con J1 scollegato: resistenza tra E+ ed E− **≈ 47,2 kΩ** (circa 35 kΩ indica una posizione con due resistenze).
4. Collegare J1 e misurare V<sub>ex</sub>; tensione tra X e Y **≈ V<sub>ex</sub> · 4,23·10⁻³** (≈ 13,5 mV con 3,2 V).
5. A+ − A− agli estremi della corsa: **≈ ±V<sub>ex</sub> · 2,114·10⁻³** (≈ ±6,8 mV con 3,2 V).
