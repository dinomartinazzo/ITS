# Simulatore di cella di carico — ponte da 348 Ω, PCB rev P2 (compatto)

Simulatore con **ponte di Wheatstone reale da 348 Ω** (valore E96 più vicino a 350 Ω).
Lo sbilanciamento si ottiene iniettando una piccola corrente nel nodo A+ dal cursore di RV1
attraverso R5; RV2 con R6 compensa l'offset iniziale del ponte.
Versione compatta: le sei resistenze sono in una sola colonna (R5, R6, R1, R2, R4, R3), con i lati A+ e A−
tutti a destra verso J1 e i lati E+, E−, cursori tutti a sinistra; RV1 è orizzontale sopra la colonna.

## Dati di progetto

| Grandezza | Valore |
|---|---|
| Fondo scala (RV1 agli estremi) | ±2,006 mV/V |
| Impedenza d'uscita | ≈ 348 Ω |
| Carico sull'eccitazione | ≈ 288 Ω: ≈ 11 mA a 3,2 V, ≈ 17 mA a 5 V |
| Non linearità dovuta a RV1 (2 kΩ) | ≤ 0,44% del fondo scala |
| Campo di regolazione dello zero (RV2) | ±1,21 mV/V |
| Offset iniziale, caso peggiore, R1–R4 allo 0,1% | ±1,0 mV/V |
| Deriva dello zero, caso peggiore, 25 ppm/°C | 0,025 mV/V per °C |

## Caratteristiche della scheda

| Parametro | Valore |
|---|---|
| Dimensioni | 36 × 28 mm (rev P1: 43 × 35 mm, −33% di superficie), 2 fori M2,5 |
| Strati | 2 (rame 1 oz), spessore 1,6 mm |
| Resistenze | Footprint combinati: 0805 oppure assiali DIN0207 passo 10,16 mm (una sola per posizione) |
| Lato rame | E+ verso J1, ritorni E−, cursore di RV2: quattro piste brevi, nessuna su A+ o A− |
| DRC (KiCad 7.0.11) | 0 violazioni, 0 pad non collegati; reti verificate contro lo schema |

## Connessioni

| Connettore | Pin 1 | Pin 2 | Pin 3 | Pin 4 |
|---|---|---|---|---|
| J1 (verso il convertitore) | E+ | A+ | A− | E− |
| RV1 (2 kΩ, a pannello) | E+ | cursore | E− | — |
| RV2 (10 kΩ, trimmer) | E+ | cursore | E− | — |

## File

| File | Contenuto |
|---|---|
| `simulatore_ponte_350_compatto.kicad_pro`, `.kicad_pcb` | Progetto KiCad 7 |
| `fp-lib-table`, `Simulatore.pretty/` | Libreria dei footprint |
| `gerber/` | Gerber RS-274X, forature Excellon, file di job |
| `stampa_1a1/` | Stampe 1:1: rame del lato componenti specchiato, rame del lato saldature, serigrafia |
| `simulatore_ponte_350_compatto-bom.csv` | Distinta componenti |
| `simulatore_ponte_350_compatto-pos-0805.csv` | Piazzamento delle 0805 |
| `build_pcb_ponte_compatto.py` | Script che genera la scheda con l'API pcbnew |

## Montaggio, taratura e collaudo

1. Montare R1–R4 dello stesso lotto: sono nelle quattro file centrali-inferiori, a 3,2 mm l’una dall’altra, quindi alla stessa temperatura.
2. Con J1 scollegato e RV1, RV2 non montati: resistenza tra E+ ed E− **≈ 348 Ω**; tra A+ e A− **≈ 348 Ω**.
3. Montare RV1 e RV2; collegare J1 al convertitore e misurare V<sub>ex</sub>.
4. Portare RV1 a metà corsa (5 giri da un estremo) e regolare RV2 finché A+ − A− = 0 ± 10 µV.
5. RV1 agli estremi: A+ − A− = **±V<sub>ex</sub> · 2,006·10⁻³** (±6,42 mV con 3,2 V), simmetrici entro l'1%.
6. Verificare l'eccitazione sotto carico: E+ − E− con il simulatore collegato non deve calare più dell'1% rispetto a vuoto.
