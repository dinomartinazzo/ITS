# build_pcb_ponte_compatto.py — ponte da 348 ohm, versione compatta a colonna unica; footprint combinati
import pcbnew
from pcbnew import VECTOR2I, FromMM

OUT = '/home/claude/pcb/ponte_c/simulatore_ponte_350_compatto/simulatore_ponte_350_compatto.kicad_pcb'
X0, Y0 = 98.5, 97.5            # origine della scheda [mm]
W, H = 36.0, 28.0              # dimensioni della scheda [mm]
TRACK = 0.3                    # larghezza piste [mm]

board = pcbnew.BOARD()
board.SetCopperLayerCount(2)
ds = board.GetDesignSettings()
ds.SetCopperLayerCount(2)
ds.m_TrackMinWidth = FromMM(0.2)
ds.m_MinClearance = FromMM(0.2)

def P(x, y):
    return VECTOR2I(FromMM(x), FromMM(y))

# --- Reti ---
nets = {}
for name in ('E+', 'E-', 'A+', 'A-', 'W1', 'W2'):
    n = pcbnew.NETINFO_ITEM(board, name)
    board.Add(n)
    nets[name] = n


def fix_local(fp):
    # il footprint è costruito nell'origine: le coordinate assolute coincidono con quelle locali
    for pad in fp.Pads():
        pad.SetPos0(pad.GetPosition())
    for item in fp.GraphicalItems():
        item.SetLocalCoord()
    fp.Reference().SetLocalCoord()
    fp.Value().SetLocalCoord()

# --- Footprint generati qui (equivalenti a quelli standard KiCad) ---
def text(fp, kind, txt, x, y, layer, size=0.8):
    t = fp.Reference() if kind == 'ref' else fp.Value()
    t.SetText(txt)
    t.SetLayer(layer)
    t.SetTextSize(VECTOR2I(FromMM(size), FromMM(size)))
    t.SetTextThickness(FromMM(0.12))
    t.SetPosition(P(x, y))

def fp_r0805(ref, val, x, y, n1, n2, vertical=False, lbl=None):
    fp = pcbnew.FOOTPRINT(board)
    fp.SetFPID(pcbnew.LIB_ID('Simulatore', 'R_0805_2012Metric'))
    ox, oy = x, y
    x, y = 0.0, 0.0
    for num, dx, net in (('1', -0.9125, n1), ('2', 0.9125, n2)):
        pad = pcbnew.PAD(fp)
        pad.SetNumber(num)
        pad.SetShape(pcbnew.PAD_SHAPE_ROUNDRECT)
        pad.SetRoundRectRadiusRatio(0.243902)
        pad.SetAttribute(pcbnew.PAD_ATTRIB_SMD)
        pad.SetLayerSet(pad.SMDMask())
        pad.SetSize(VECTOR2I(FromMM(1.025), FromMM(1.4)))
        pad.SetPosition(P(x + dx, y))
        pad.SetNet(nets[net])
        fp.Add(pad)
    # sagoma sul layer Fab e serigrafia minima
    for (xa, ya, xb, yb) in ((-1, -0.625, 1, -0.625), (1, -0.625, 1, 0.625), (1, 0.625, -1, 0.625), (-1, 0.625, -1, -0.625)):
        seg = pcbnew.FP_SHAPE(fp, pcbnew.SHAPE_T_SEGMENT)
        seg.SetStart(P(x + xa, y + ya)); seg.SetEnd(P(x + xb, y + yb))
        seg.SetLayer(pcbnew.F_Fab); seg.SetWidth(FromMM(0.1))
        fp.Add(seg)
    fp.SetAttributes(pcbnew.FP_SMD)
    text(fp, 'val', val, 0, 0, pcbnew.F_Fab, 0.5)
    text(fp, 'ref', ref, 0, -1.6, pcbnew.F_SilkS)
    board.Add(fp)
    fix_local(fp)
    fp.SetPosition(P(ox, oy))
    if vertical:
        fp.SetOrientationDegrees(90)   # rotazione attorno al centro: pad 1 in basso, pad 2 in alto
    lx, ly = lbl if lbl else (ox, oy - 1.6)
    fp.Reference().SetPosition(P(lx, ly))
    if vertical:
        fp.Reference().SetTextAngleDegrees(-90)   # angolo relativo al footprint: testo orizzontale
    return fp

def fp_header(ref, val, x, y, n, netlist, labels=None, lib='PinHeader'):
    fp = pcbnew.FOOTPRINT(board)
    fp.SetFPID(pcbnew.LIB_ID('Simulatore', f'{lib}_1x{n:02d}_P2.54mm_Vertical'))
    ox, oy = x, y
    x, y = 0.0, 0.0
    for i in range(n):
        pad = pcbnew.PAD(fp)
        pad.SetNumber(str(i + 1))
        pad.SetShape(pcbnew.PAD_SHAPE_RECT if i == 0 else pcbnew.PAD_SHAPE_OVAL)
        pad.SetAttribute(pcbnew.PAD_ATTRIB_PTH)
        pad.SetLayerSet(pad.PTHMask())
        pad.SetSize(VECTOR2I(FromMM(1.7), FromMM(1.7)))
        pad.SetDrillSize(VECTOR2I(FromMM(1.0), FromMM(1.0)))
        pad.SetPosition(P(x, y + i * 2.54))
        pad.SetNet(nets[netlist[i]])
        fp.Add(pad)
    # rettangolo di serigrafia attorno ai pin
    r = (x - 1.33, y - 1.33, x + 1.33, y + (n - 1) * 2.54 + 1.33)
    for (xa, ya, xb, yb) in ((r[0], r[1], r[2], r[1]), (r[2], r[1], r[2], r[3]), (r[2], r[3], r[0], r[3]), (r[0], r[3], r[0], r[1])):
        seg = pcbnew.FP_SHAPE(fp, pcbnew.SHAPE_T_SEGMENT)
        seg.SetStart(P(xa, ya)); seg.SetEnd(P(xb, yb))
        seg.SetLayer(pcbnew.F_SilkS); seg.SetWidth(FromMM(0.12))
        fp.Add(seg)
    fp.SetAttributes(pcbnew.FP_THROUGH_HOLE)
    text(fp, 'ref', ref, 0, -2.4, pcbnew.F_SilkS)
    text(fp, 'val', val, 0, n * 2.54, pcbnew.F_Fab, 0.6)
    board.Add(fp)
    fix_local(fp)
    fp.SetPosition(P(ox, oy))
    return fp

def fp_hole(ref, x, y, d=3.2):
    fp = pcbnew.FOOTPRINT(board)
    fp.SetFPID(pcbnew.LIB_ID('Simulatore', 'MountingHole_2.7mm_M2.5' if d < 3 else 'MountingHole_3.2mm_M3'))
    ox, oy = x, y
    x, y = 0.0, 0.0
    pad = pcbnew.PAD(fp)
    pad.SetNumber('')
    pad.SetShape(pcbnew.PAD_SHAPE_CIRCLE)
    pad.SetAttribute(pcbnew.PAD_ATTRIB_NPTH)
    pad.SetLayerSet(pad.UnplatedHoleMask())
    pad.SetSize(VECTOR2I(FromMM(d), FromMM(d)))
    pad.SetDrillSize(VECTOR2I(FromMM(d), FromMM(d)))
    pad.SetPosition(P(x, y))
    fp.Add(pad)
    fp.Reference().SetVisible(False)
    fp.Value().SetVisible(False)
    fp.SetReference(ref)
    fp.SetAttributes(pcbnew.FP_EXCLUDE_FROM_BOM | pcbnew.FP_EXCLUDE_FROM_POS_FILES)
    board.Add(fp)
    fix_local(fp)
    fp.SetPosition(P(ox, oy))


PITCH = 10.16      # passo dei fori per resistenze assiali DIN0207 (1/4 W)

def fp_combo(ref, val, x, y, n1, n2, vertical=False, lbl=None):
    """Footprint combinato: pad 0805 al centro e fori per resistenza assiale, stessi numeri di pad."""
    fp = pcbnew.FOOTPRINT(board)
    fp.SetFPID(pcbnew.LIB_ID('Simulatore', 'R_Combo_0805_Axial_P10.16mm'))
    for num, sgn, net in (('1', -1, n1), ('2', 1, n2)):
        smd = pcbnew.PAD(fp)                                   # piazzola 0805 (come R_0805_2012Metric)
        smd.SetNumber(num)
        smd.SetShape(pcbnew.PAD_SHAPE_ROUNDRECT); smd.SetRoundRectRadiusRatio(0.243902)
        smd.SetAttribute(pcbnew.PAD_ATTRIB_SMD); smd.SetLayerSet(smd.SMDMask())
        smd.SetSize(VECTOR2I(FromMM(1.025), FromMM(1.4)))
        smd.SetPosition(P(sgn * 0.9125, 0)); smd.SetNet(nets[net])
        fp.Add(smd)
        tht = pcbnew.PAD(fp)                                   # foro per resistenza assiale
        tht.SetNumber(num)
        tht.SetShape(pcbnew.PAD_SHAPE_RECT if num == '1' else pcbnew.PAD_SHAPE_CIRCLE)
        tht.SetAttribute(pcbnew.PAD_ATTRIB_PTH); tht.SetLayerSet(tht.PTHMask())
        tht.SetSize(VECTOR2I(FromMM(1.6), FromMM(1.6)))
        tht.SetDrillSize(VECTOR2I(FromMM(0.8), FromMM(0.8)))
        tht.SetPosition(P(sgn * PITCH / 2, 0)); tht.SetNet(nets[net])
        fp.Add(tht)
    # sagoma del corpo assiale DIN0207 (6,3 x 2,5 mm) in serigrafia: contiene le piazzole 0805
    for (xa, ya, xb, yb) in ((-3.15, -1.25, 3.15, -1.25), (3.15, -1.25, 3.15, 1.25), (3.15, 1.25, -3.15, 1.25), (-3.15, 1.25, -3.15, -1.25)):
        seg = pcbnew.FP_SHAPE(fp, pcbnew.SHAPE_T_SEGMENT)
        seg.SetStart(P(xa, ya)); seg.SetEnd(P(xb, yb))
        seg.SetLayer(pcbnew.F_SilkS); seg.SetWidth(FromMM(0.12))
        fp.Add(seg)
    fp.SetAttributes(0)                                         # né solo SMD né solo THT: montaggio a scelta
    text(fp, 'val', val, 0, 0, pcbnew.F_Fab, 0.5)
    text(fp, 'ref', ref, 0, -2.2, pcbnew.F_SilkS)
    board.Add(fp)
    fix_local(fp)
    fp.SetPosition(P(x, y))
    if vertical:
        fp.SetOrientationDegrees(90)                            # pad 1 in basso, pad 2 in alto
        fp.Reference().SetTextAngleDegrees(-90)
    lx, ly = lbl if lbl else (x, y - 2.2)
    fp.Reference().SetPosition(P(lx, ly))
    # collegamento fisico tra piazzola SMD e foro con lo stesso numero
    pads = {}
    for pad in fp.Pads():
        pads.setdefault(pad.GetNumber(), []).append(pad)
    for num, pp in pads.items():
        a, b = pp[0].GetPosition(), pp[1].GetPosition()
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(a); t.SetEnd(b); t.SetWidth(FromMM(0.4)); t.SetLayer(pcbnew.F_Cu)
        t.SetNet(pp[0].GetNet())
        board.Add(t)
    return fp



# --- Coordinate di progetto (mm): sei resistenze in colonna, lato A a destra, lato E/W a sinistra ---
ROW = 3.2
xL = 110.0
xR = xL + PITCH                                  # 120,16
xc = (xL + xR) / 2
rows = [104.0 + k * ROW for k in range(6)]       # 104,0 107,2 110,4 113,6 116,8 120,0
xE = xL - 2.54                                   # dorsale di E+ (lato componenti), 107,46
xRV2 = 103.0                                     # trimmer dello zero, verticale
yRV1 = 100.4                                     # potenziometro di span, orizzontale sopra la colonna
xJ, xEm = 126.0, 128.5                           # connettore e discesa di E-
yJ = [rows[3] - 2.54, rows[3], rows[3] + 2.54, rows[3] + 5.08]   # E+, A+, A-, E-
B = pcbnew.B_Cu

# ordine dall'alto: R5 (W1|A+), R6 (W2|A+), R1 (E+|A+), R2 (E-|A+), R4 (E-|A-), R3 (E+|A-)
order = [('R5', '43k2 0,1%', 'W1', 'A+'), ('R6', '71k5 1%', 'W2', 'A+'), ('R1', '348R 0,1%', 'E+', 'A+'),
         ('R2', '348R 0,1%', 'E-', 'A+'), ('R4', '348R 0,1%', 'E-', 'A-'), ('R3', '348R 0,1%', 'E+', 'A-')]
lbls = [(122.6, rows[0]), (122.6, rows[1]), (122.6, rows[2]), (122.6, 112.6), (123.0, 117.4), (122.6, rows[5])]
for (ref, val, n1, n2), y, lb in zip(order, rows, lbls):
    fp_combo(ref, val, xc, y, n1, n2, lbl=lb)

# RV1 orizzontale (rotazione 90°): pin 1 E+ a 107,46, pin 2 cursore a 110,00 sopra R5, pin 3 E- a 112,54
rv1 = fp_header('RV1', '2k SPAN 3590S (pannello)', xE, yRV1, 3, ['E+', 'W1', 'E-'])
rv1.SetOrientationDegrees(90)
rv1.Reference().SetTextAngleDegrees(-90)
rv1.Reference().SetPosition(P(103.8, yRV1 - 0.3))
rv1.Value().SetTextAngleDegrees(-90)
rv1.Value().SetPosition(P(119.0, 99.0))           # solo layer Fab, dentro il contorno
rv2 = fp_header('RV2', '10k ZERO 3296W', xRV2, rows[1] - 2.54, 3, ['E+', 'W2', 'E-'], lib='Trimmer')
rv2.Reference().SetPosition(P(xRV2, 113.2))
j1 = fp_header('J1', 'Conn_01x04', xJ, yJ[0], 4, ['E+', 'A+', 'A-', 'E-'])
j1.Reference().SetPosition(P(xJ, yJ[0] - 2.0))
for (hx, hy) in ((101.5, 122.5), (131.5, 100.5)):
    fp_hole('H', hx, hy, 2.7)

def track(points, net, layer=pcbnew.F_Cu):
    for (a, b) in zip(points[:-1], points[1:]):
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(P(*a)); t.SetEnd(P(*b))
        t.SetWidth(FromMM(TRACK)); t.SetLayer(layer); t.SetNet(nets[net])
        board.Add(t)

# E+: dorsale verticale a sinistra della colonna (lato componenti)
track([(xE, yRV1), (xE, rows[5]), (xL, rows[5])], 'E+')
track([(xE, rows[2]), (xL, rows[2])], 'E+')
track([(xRV2, rows[1] - 2.54), (xE, rows[1] - 2.54)], 'E+')
# E+ verso J1 sul lato rame, tra la seconda e la terza fila
yg12 = (rows[1] + rows[2]) / 2                    # 108,8
track([(xL, rows[2]), (xL + 1.6, yg12), (124.3, yg12), (xJ, yJ[0])], 'E+', B)
# cursori
track([(xL, yRV1), (xL, rows[0])], 'W1')
track([(xRV2, rows[1]), (xL, rows[1])], 'W2', B)
# E-: collegamento delle file 4 e 5, ritorni dei potenziometri e J1
track([(xL, rows[3]), (xL, rows[4])], 'E-')
track([(xRV2, rows[1] + 2.54), (xRV2, rows[3]), (xL, rows[3])], 'E-', B)
track([(xE + 5.08, yRV1), (xEm, yRV1), (xEm, yJ[3]), (xJ, yJ[3])], 'E-')
yg34 = (rows[3] + rows[4]) / 2                    # 115,2
track([(xL, rows[4]), (xL + 1.6, yg34), (124.3, yg34), (124.3, yJ[2] + 0.94), (xJ, yJ[3])], 'E-', B)
# A+ e A-
track([(xR, rows[0]), (xR, rows[3]), (xJ, yJ[1])], 'A+')
track([(xR, rows[4]), (xR, rows[5])], 'A-')
track([(xR, rows[4]), (xR + (rows[4] - yJ[2]), yJ[2]), (xJ, yJ[2])], 'A-')

def edge(xa_, ya_, xb_, yb_):
    s = pcbnew.PCB_SHAPE(board, pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(P(xa_, ya_)); s.SetEnd(P(xb_, yb_))
    s.SetLayer(pcbnew.Edge_Cuts); s.SetWidth(FromMM(0.1))
    board.Add(s)
edge(X0, Y0, X0 + W, Y0); edge(X0 + W, Y0, X0 + W, Y0 + H)
edge(X0 + W, Y0 + H, X0, Y0 + H); edge(X0, Y0 + H, X0, Y0)

def silk(txt, x, y, size=0.8, layer=pcbnew.F_SilkS):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(txt); t.SetLayer(layer)
    t.SetTextSize(VECTOR2I(FromMM(size), FromMM(size)))
    t.SetTextThickness(FromMM(0.15 if size >= 1 else 0.12))
    t.SetPosition(P(x, y))
    if layer == pcbnew.B_SilkS:
        t.SetMirrored(True)
    board.Add(t)

for lab, y in zip(('E+', 'A+', 'A-', 'E-'), yJ):
    silk(lab, 130.6, y)
silk('PONTE 348R  ±2 mV/V', 117.5, 123.6)
silk('SPAN', 103.8, 101.7)
silk('ZERO', xRV2, 114.4)
silk('rev P2 10/2026', 117.5, 123.6, 0.8, pcbnew.B_SilkS)

board.SetFileName(OUT)
pcbnew.SaveBoard(OUT, board)
print('salvato', OUT)
